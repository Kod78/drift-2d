
package com.guess.drift2d

import android.util.Log
import com.google.firebase.database.*

class MultiplayerManager {

    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private lateinit var playerRef: DatabaseReference
    private lateinit var enemyRef: DatabaseReference

    fun connect(playerId: String, enemyId: String, onEnemyMove: (Float, Float, Float) -> Unit) {
        playerRef = database.getReference("players").child(playerId)
        enemyRef = database.getReference("players").child(enemyId)

        // Слушаем движения соперника
        enemyRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val x = snapshot.child("x").getValue(Float::class.java) ?: 0f
                val y = snapshot.child("y").getValue(Float::class.java) ?: 0f
                val angle = snapshot.child("angle").getValue(Float::class.java) ?: 0f
                onEnemyMove(x, y, angle)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Multiplayer", "Database error: ${error.message}")
            }
        })
    }

    fun updatePlayerPosition(x: Float, y: Float, angle: Float) {
        val position = mapOf(
            "x" to x,
            "y" to y,
            "angle" to angle
        )
        playerRef.setValue(position)
    }
}
