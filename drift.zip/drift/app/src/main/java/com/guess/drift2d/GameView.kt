package com.guess.drift2d

import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.concurrent.thread
import kotlin.math.cos
import kotlin.math.sin

class GameView(context: Context, attrs: AttributeSet?) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    private val prefs: SharedPreferences = context.getSharedPreferences("game_prefs", Context.MODE_PRIVATE)

    private var level = prefs.getInt("level", 1)
    private var score = 0
    private var paused = false
    private var difficulty = 1.0f + (level - 1) * 0.3f

    private val carBitmap = BitmapFactory.decodeResource(resources, R.drawable.player_car)
    private val enemyBitmap = BitmapFactory.decodeResource(resources, R.drawable.player_car) // или другой

    private var carX = 200f
    private var carY = 800f
    private var velocity = 0f
    private var angle = 0f

    private var enemyX = 200f
    private var enemyY = 600f
    private var enemyAngle = 0f

    private var running = false

    private val multiplayer = MultiplayerManager()

    init {
        holder.addCallback(this)
        isFocusable = true

        multiplayer.connect("player1", "player2") { x, y, a ->
            enemyX = x
            enemyY = y
            enemyAngle = a
        }
    }

    private fun update() {
        if (paused) return

        velocity *= 0.98f
        carX += (cos(Math.toRadians(angle.toDouble())) * velocity * difficulty).toFloat()
        carY += (sin(Math.toRadians(angle.toDouble())) * velocity * difficulty).toFloat()

        multiplayer.updatePlayerPosition(carX, carY, angle)

        if (carX > width) {
            level++
            difficulty += 0.3f
            score += 100
            carX = 0f
            carY = 800f
            prefs.edit().putInt("level", level).apply()
        }
    }

    private fun drawGame(canvas: Canvas) {
        canvas.drawColor(Color.DKGRAY)

        val matrix = Matrix().apply {
            postRotate(angle, carBitmap.width / 2f, carBitmap.height / 2f)
            postTranslate(carX, carY)
        }
        canvas.drawBitmap(carBitmap, matrix, null)

        val enemyMatrix = Matrix().apply {
            postRotate(enemyAngle, enemyBitmap.width / 2f, enemyBitmap.height / 2f)
            postTranslate(enemyX, enemyY)
        }
        canvas.drawBitmap(enemyBitmap, enemyMatrix, null)

        val paint = Paint().apply {
            color = Color.WHITE
            textSize = 48f
            typeface = Typeface.MONOSPACE
        }
        canvas.drawText("Score: $score", 30f, 80f, paint)
        canvas.drawText("Level: $level", 30f, 140f, paint)
        if (paused) canvas.drawText("PAUSED", width / 2f - 100f, height / 2f, paint)
    }

    private fun gameLoop() {
        thread {
            while (running) {
                if (!holder.surface.isValid) continue
                val canvas = holder.lockCanvas()
                update()
                drawGame(canvas)
                holder.unlockCanvasAndPost(canvas)
                Thread.sleep(16)
            }
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        gameLoop()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (paused) return true
        if (event.action == MotionEvent.ACTION_DOWN) {
            velocity += 10f
            angle += 15f
        }
        return true
    }

    fun togglePause() {
        paused = !paused
    }
}